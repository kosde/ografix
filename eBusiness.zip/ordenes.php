<?php
session_start();
if(isset($_SESSION['id']))
{
    $id_user = $_SESSION['id'];
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Ografix</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
  <!-- 5-=DXbZ]Ggah -->
  <link href="img/ICONO.png" rel="icon">
  <link href="img/ICONO.png" rel="apple-touch-icon">
  <?php
  include "css.php";
  ?>
    <script src="https://kit.fontawesome.com/a38c16a07e.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body data-spy="scroll" data-target="#navbar-example" class="estaciones">
<?php  include "header.php";?>
    <div id="subnav" class="container" style="width: min-content;margin: auto;">   
        <div class="container" style="--subnav-scroll-left-width:0px; --subnav-scroll-right-width:0px;">
            <div class="subnav-menu">
                <ul class="subnav-menu-tabs">
                    <a class="a-subnav-menu" href="perfil"><li class=" li-subnav ">Perfil</li></a>
                    <a class="a-subnav-menu" href="ordenes" style="color: #202020;" >        <li class="li-subnav active">Ordenes</li></a>
                    <a class="a-subnav-menu" href="reordenes">       <li class="li-subnav">Reordenes</li></a>      
                    <a class="a-subnav-menu" href="trabajos">      <li class="li-subnav">Trabajos</li></a>     
                    <a class="a-subnav-menu" href="notificaciones"> <li class="li-subnav">Notificaciones</li></a>
                </ul>
            </div>
        </div>
    </div>
        <?php
        include 'php/conexion.php';
        include 'php/fecha.php';
        $query = "SELECT * FROM orders WHERE id_user='$id_user' ORDER BY id DESC";
        $result = mysqli_query($conexion,$query);
        if(mysqli_num_rows($result)==0)
        {
        ?>
            <div class="container"  style="height: 100vh;width: min-content;">
                <div class="container">
                    <h1 style="font-size: 2.5rem;margin-bottom:0;">Historial</h1>
                    <label class="font-light">Aun no hay ordenes, <a href="index" style="color:#2b71b8;">realiza tu primera orden.</a></label>
                </div>
            </div>
        <?php
        }
        if(mysqli_num_rows($result)>0)
        {
        ?>
            <div class="container"  style="height: 100vh;padding-bottom: 80px;padding-top: 80px;width: min-content;margin: auto;">
                <div id="main" class="wrapper container">
                <h1 style="font-size: 2.5rem;margin-bottom:0;">Historial</h1>
                    <table class="responsive" style="width: 100%;">
                        <thead>
                        <tr>
                            <th class="font-medium">ID</th>
                            <th class="font-medium">Fecha</th>
                            <th class="font-medium">Estatus</th>
                            <th class="currency font-medium" style="width: 20%;text-align: right;">Total</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            
                                while ($extraido= mysqli_fetch_array($result))
                                {
                                    $id             = $extraido['id'];
                                    $width_inches   = $extraido['width_inches'];
                                    $height_inches  = $extraido['height_inches'];
                                    $price          = $extraido['price'];
                                    $tipe           = $extraido['tipe'];
                                    $quantity       = $extraido['quantity'];
                                    $id_images      = $extraido['id_images'];
                                    $txt_details    = $extraido['txt_details'];
                                    $dates          = $extraido['dates'];
                                    $statusp        = $extraido['statusp'];
                                    $id_address     = $extraido['id_address'];
                                    $id_control     = $extraido['id_control'];
                                    //date_default_timezone_set('America/Mexico_City');
                                    //$date = date_create($dates);
                                    $date = fechaEspanol($dates);//date_format($date,"F j, Y");
                                    //setlocale(LC_TIME, "spanish");
                                    //$date = strftime("%d de %j %Y",strtotime($date));
                                    ?>
                                    <tr class="bigger-row even" style="display: table-row;height: 40px;">
                                        <td data-label="Order number" class="fontlight">GRFX<?php echo $id_control;?><!--<a href="detalles_orden?order=<?php // echo $id;?>"></a>--></td>
                                        <td data-label="Order date" class="fontlight"><?php echo $date;?></td>
                                        <?php
                                            if($statusp==6 || $statusp==11)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="seguimiento?order=<?php echo $id;?>">!-->En producción<!--</a> --></td>
                                            <?php
                                            }
                                            ?>
                                            <?php
                                            if($statusp==0)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="prueba?order=<?php echo $id;?>">!-->Pendiente de prueba<!--</a> --></td>
                                            <?php
                                            }
                                            ?>
                                            <?php
                                            if($statusp==1)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="prueba?order=<?php echo $id;?>">!-->Pendiente de aprobación<!--</a> --></td>
                                            <?php
                                            }
                                            ?>
                                            <?php
                                            if($statusp==2)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="seguimiento?order=<?php echo $id;?>">!-->Aprobado<!--</a> --></td>
                                            <?php
                                            }
                                            ?>
                                            <?php
                                            if($statusp==4)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="seguimiento?order=<?php echo $id;?>">!-->Cancelado<!--</a> --></td>
                                            <?php
                                            }
                                            ?>
                                            <?php
                                            if($statusp==5)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="seguimiento?order=<?php echo $id;?>">!-->Enviado<!--</a> --></td>
                                            <?php
                                            }
                                            if($statusp==7)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="seguimiento?order=<?php echo $id;?>">!-->En impresión<!--</a> --></td>
                                            <?php
                                            }
                                            if($statusp==8)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="seguimiento?order=<?php echo $id;?>">!-->En ruta<!--</a> --></td>
                                            <?php
                                            }
                                            if($statusp==9)
                                            {
                                            ?>
                                                <td data-label="Status" class="fontlight"><!--<a href="seguimiento?order=<?php echo $id;?>">!-->Entregado<!--</a> --></td>
                                            <?php
                                            }
                                        ?>
                                            <td data-label="Total" class="fontlight currency" style="text-align: right;">$ <?php echo $price;?></td>
                                        </tr>
                                        <?php
                                }
                            ?>
                        
                        </tbody>
                    </table>
                </div>
            </div>
        <?php
        }
        ?>
    <?php
  include "footer.php";
  ?>
    <script src="js/jquery-3.5.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <script src="js/bootsnav/bootsnav.js"></script>
    <script src="js/script.js"></script>
</body>
</html>
<?php
}
else{
    echo'
    <script>
        window.location = "../identificate";
    </script>
    ';
}
?>