<footer style="background-color: lightgray;width: min-content;" class="container">
    <div class="footer-area container" style="display: none;visibility: hidden;">
      <div class="container" style="background-color: lightgray;">
        <div class="row">
          <h4 class="credits">Informacion</h4>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head credits">
                <div class="footer-contacts">
                  <p><span>Telefono:</span> 44 48 47 12 16</p>
                </div>
              <!--  <div class="footer-logo">
                  <h2>Ografix</h2>
                </div>

                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis.</p>
                <div class="footer-icons">
                  <ul>
                    <li>
                      <a href="#"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-google"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-pinterest"></i></a>
                    </li>
                  </ul>
                </div> -->
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head credits">
                
                <div class="footer-contacts">
                 <!-- <p><span>Telefono:</span> 44 48 47 12 16</p>-->
                  <p><span>Email:</span> ografix@gmail.com</p>
                 <!-- <p><span>Horario:</span> 8am-6pm</p>-->
                </div>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="footer-content">
              <div class="footer-head credits">
                <div class="footer-contacts">
                   <p><span>Horario:</span> 9am-6pm</p>
                 </div>
               <!-- <h4>Instagram</h4>
                <div class="flicker-img">
                  <a href="#"><img src="img/slider/Anuncio Luminoso.jpg" alt=""></a>
                  <a href="#"><img src="img/slider/Art. Promocionales.jpg" alt=""></a>
                  <a href="#"><img src="img/slider/Diseño Grafico.jpg" alt=""></a>
                  <a href="#"><img src="img/slider/Diseño Web.jpg" alt=""></a>
                  <a href="#"><img src="img/slider/Tarjeta de Presentacion.jpg" alt=""></a>
                  <a href="#"><img src="img/slider/Toldos Fijos y Enrollables.jpg" alt=""></a>
                </div>-->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-area-bottom container" style="background-color: lightgray;">
      <div class="container" style="background-color: lightgray;">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="copyright text-center">
              <p>
                &copy; Copyright <strong>Ografix</strong>. All Rights Reserved
              </p>
            </div>
            <div class="credits">
              <!--
                All the links in the footer should remain intact.
                You can delete the links only if you purchased the pro version.
                Licensing information: https://bootstrapmade.com/license/
                Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=eBusiness
              -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>