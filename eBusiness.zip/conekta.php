<?php
    echo "inicio";
    require_once("conekta-php\lib\Conekta.php");
    \Conekta\Conekta::setApiKey("key_shUYg3ZZr5wxdpD1fs9kqA");
    \Conekta\Conekta::setApiVersion("4.3.0");//4.3.0  2.0.0
    $validCustomer = [
        'name' => "Payment Link Name",
        'email' => "Juan Perez"
    ];
    $customer = Customer::create($validCustomer);
    echo $customer->livemode;
    echo $customer->name;
    echo $customer->email;
    echo $customer->id;
    echo $customer->object;
