// Usage: https://github.com/RobinHerbots/Inputmask
import Inputmask from "inputmask";

window.Inputmask = Inputmask;

Inputmask().mask(document.querySelectorAll("input"));