// Usage: https://joshuajohnson.co.uk/Choices/
import Choices from "choices.js";

window.Choices = Choices;