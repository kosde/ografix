export default `<div class="settings js-settings">
    <div class="settings-icons">
      <div class="settings-icon js-settings-toggle" data-bs-toggle="tooltip" data-bs-placement="left" title="Settings & Demos">
        <i class="align-middle" data-feather="settings"></i>
      </div>
      <a class="settings-icon" data-bs-toggle="tooltip" data-bs-placement="left" title="Documentation" href="https://adminkit.io/docs" target="_blank">
        <i class="align-middle" data-feather="book-open"></i>
      </a>
    </div>

    <div class="settings-panel">
      <div class="settings-content">
        <div class="settings-title">
          <button type="button" class="btn-close btn-close-white float-end js-settings-toggle" aria-label="Close"></button>

          <h4 class="text-white mb-0 d-inline-block">Settings</h4>
          <span class="badge bg-light ms-2">Pro</span>
        </div>

        <div class="settings-options">

          <div class="alert alert-warning" role="alert">
            <div class="alert-message">
              <strong>Customize</strong> sidebar position, color scheme and layout type.
            </div>
          </div>

          <div class="mb-3">
            <small class="d-block text-uppercase font-weight-bold text-muted mb-2">Color scheme</small>
            <div class="form-check form-switch mb-1">
              <input type="radio" class="form-check-input" name="theme" value="default" id="themeDefault" checked>
              <label class="form-check-label" for="themeDefault">Default</label>
            </div>
            <div class="form-check form-switch mb-1">
              <input type="radio" class="form-check-input" name="theme" value="dark" id="themeDark">
              <label class="form-check-label" for="themeDark">Dark</label>
            </div>
            <div class="form-check form-switch mb-1">
              <input type="radio" class="form-check-input" name="theme" value="light" id="themeLight">
              <label class="form-check-label" for="themeLight">Light</label>
            </div>
          </div>
          
          <hr />

          <div class="mb-3">
            <small class="d-block text-uppercase font-weight-bold text-muted mb-2">Sidebar</small>
            <div class="form-check form-switch mb-1">
              <input type="radio" class="form-check-input" name="sidebar" value="left" id="sidebarLeft" checked>
              <label class="form-check-label" for="sidebarLeft">Left</label>
            </div>
            <div class="form-check form-switch mb-1">
              <input type="radio" class="form-check-input" name="sidebar" value="right" id="sidebarRight">
              <label class="form-check-label" for="sidebarRight">Right</label>
            </div>
          </div>

          <hr />
          
          <div class="mb-3">
            <small class="d-block text-uppercase font-weight-bold text-muted mb-2">Layout</small>
            <div class="form-check form-switch mb-1">
              <input type="radio" class="form-check-input" name="layout" value="fluid" id="layoutFluid" checked>
              <label class="form-check-label" for="layoutFluid">Fluid</label>
            </div>
            <div class="form-check form-switch mb-1">
              <input type="radio" class="form-check-input" name="layout" value="boxed" id="layoutBoxed">
              <label class="form-check-label" for="layoutBoxed">Boxed</label>
            </div>
          </div>

          <div class="d-grid gap-2 mb-3">
            <a href="#" class="btn btn-outline-primary btn-lg js-settings-reset">Reset to Default</a>
            <a href="https://adminkit.io/pricing" target="_blank" class="btn btn-primary btn-lg">Purchase Now</a>
          </div>
        </div>

      </div>
    </div>
  </div>`