// Usage: https://fullcalendar.io/
import "script-loader!fullcalendar/main.min.js";