// Usage: https://quilljs.com/
import "script-loader!quill/dist/quill.min.js";