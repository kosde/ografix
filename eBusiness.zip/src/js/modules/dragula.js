// Usage: https://bevacqua.github.io/dragula/
import dragula from "dragula";

window.dragula = dragula;