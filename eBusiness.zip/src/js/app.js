import "../scss/app.scss";

// Global
import "./modules/bootstrap";
import "./modules/dragula";
import "./modules/feather";
import "./modules/notyf";
import "./modules/sidebar";
import "./modules/theme";

// Charts
import "./modules/apexcharts";
import "./modules/chartjs";

// Forms
import "./modules/choices";
import "./modules/flatpickr";
import "./modules/inputmask";
import "./modules/quill";

// Maps
import "./modules/vector-maps";
