<?php
session_start();
$email_U=$_SESSION['email_admi'];
$_SESSION['reset_pass_admi']="1";
$from = "info@acmestickers.com";
$to = $email_U;
$linkverifica = "https://www.acmestickers.com/admin/settings.php?email=".hash('sha512',$email_U);
$subject = "Reset password instructions";
$message = "We heard you lost your password. You can reset it by visiting the link below:<br>
            <a href='". $linkverifica ."'>Reset your password </a><br>
            If you did not request a password reset, please ignore this email.<br>
            Thanks,<br>
            Acme Sticker";
$headers = "From: Acme Stickers <info@acmestickers.com>"  . "\r\n". "Reply-To: info@acmestickers.com" . "\r\n" . "X-Mailer: PHP/" . phpversion() . "\r\n" .
$headers .= "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
mail($to,$subject,$message, $headers);
?> 