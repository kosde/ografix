<?php
session_start();
$conexion = $conexion =  mysqli_connect("localhost","ujrujqoxugjcs","#ceudics*vd5","dbm7i5zgqipvm1");
$actual   = $_POST['actual'];
$psw1     = $_POST['psw1'];
$psw2     = $_POST['psw2'];
$email    = $_POST['email_admin'];
if($psw1 == $psw2)
{
    $pass_u           = hash('sha512',$psw1);
    $pass_actual_hash = hash('sha512',$actual);
    $hash_email       = hash('sha512',$email);
    $query      = "SELECT * FROM users WHERE  hash_email ='$hash_email' AND pass='$pass_actual_hash'";
    $validar = mysqli_query($conexion,$query);
    if(mysqli_num_rows($validar)>0)
    {
        $activar = mysqli_query($conexion,"UPDATE users SET pass = '$pass_u' WHERE hash_email = '$hash_email'");
        if(mysqli_affected_rows($conexion) == 1)
        {
            mysqli_close($conexion);
            $_SESSION["errorpsw"]="4";
        }
        else{
            $_SESSION["errorpsw"]="3";
            mysqli_close($conexion);
        }
    }
    else{
        $_SESSION["errorpsw"]="2";
        mysqli_close($conexion);
    }
}else{
    $_SESSION["errorpsw"]="1";
    mysqli_close($conexion);
}
?>