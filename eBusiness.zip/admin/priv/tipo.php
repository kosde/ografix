<?php
    $num        = $_POST["num"];
    $id_user    = $_POST["id_user"];
   
    include "../../php/conexion.php";
    $activar = mysqli_query($conexion,"UPDATE users SET temporal  = '$num' WHERE id = '$id_user'");
    if(mysqli_affected_rows($conexion) == 1)
    {
        mysqli_close($conexion);
    }
?>