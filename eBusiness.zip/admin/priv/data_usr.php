<?php
session_start();
include "../../php/conexion.php";
$id  = $_POST['id_user'];
$validar  = mysqli_query($conexion,"SELECT * FROM users WHERE id='$id'");
if(mysqli_num_rows($validar)>0)
{
    $extraido= mysqli_fetch_array($validar);
    $_SESSION['data_id']         = $extraido['id'];
    $_SESSION['data_temporal']   = $extraido['temporal'];
    $_SESSION['data_date_create']= $extraido['date_create'];
    $_SESSION['data_active']     = $extraido ['active'];
    $_SESSION['data_name']       = $extraido['usrname'];
    $_SESSION['data_pass']       = $extraido ['pass'];
    $_SESSION['data_email']      = $extraido['email'];
    $_SESSION['data_hash_email'] = $extraido ['hash_email'];
    $_SESSION['data_code']       = $extraido['code'];
    $_SESSION['data_phone']      = $extraido ['phone'];
    $_SESSION['data_avatar']     = $extraido['avatar'];
    $_SESSION['data_admi']       = $extraido['admi'];
    $_SESSION['documento']       = $extraido['documento'];
    $_SESSION['RFC']     	= $extraido['RFC'];
     mysqli_close($conexion);
     return true;
}
?>