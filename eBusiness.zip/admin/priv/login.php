<?php
    session_start();
    include 'conexion_be.php';
    $email_u  = $_POST['email'];
    $pass_u   = $_POST['password'];
    $pass_u   = hash('sha512',$pass_u);
    //echo $email_u. " \n";
    //echo $pass_u. " \n";
    $validar  = mysqli_query($conexion,"SELECT * FROM users WHERE email='$email_u' and pass='$pass_u'");
    //echo "sqli \n";
    if(mysqli_num_rows($validar)>0)
    {
        //echo "encontrado";
        $extraido= mysqli_fetch_array($validar);
        $_SESSION['id_admi']        = $extraido['id'];
        $_SESSION['usrname_admi']   = $extraido['usrname'];
        $_SESSION['email_admi']     = $extraido['email'];
        $_SESSION['tipe_admi']      = $extraido['tipe'];
        $_SESSION['avatar_admi']    = $extraido['avatar'];//admi 
        $_SESSION['admi']           = $extraido['admi'];//admi 
        if($_SESSION['admi']==1)
        {
            $tipe = $_SESSION['tipe_admi'];
            $bin = decbin ($tipe);
            $numlength = strlen((string)$bin);
            if($tipe != 10)
            {
                $_SESSION['v_admi'] = 0;
                $_SESSION['e_admi'] = 0;
                $_SESSION['d_admi'] = 0;
                if($numlength==1)
                {
                    $_SESSION['d_admi'] =$bin;
                }
                if($numlength==2)
                {
                    $_SESSION['v_admi'] =$bin[0];
                    $_SESSION['e_admi'] =$bin[1];
                }
                if($numlength==3)
                {
                    $_SESSION['v_admi'] =$bin[0];
                    $_SESSION['e_admi'] =$bin[1];
                    $_SESSION['d_admi'] =$bin[2];
                }
            }
            mysqli_close($conexion);
            //die();
            echo'
                <script>
                    window.location = "../dashboard.php";
                </script>
                ';
        }
        else
        {
            //die();
            session_destroy();
            echo'
                <script>
                    window.location = "../index.php?error=1";
                </script>
                ';
        }
        
            
    }else{
        //echo "sqli 2 \n";
        $validar  = mysqli_query($conexion,"SELECT * FROM users WHERE usrname='$email_u' and pass='$pass_u'");
        if(mysqli_num_rows($validar)>0)
        {
            //echo "encontrado";

            $extraido= mysqli_fetch_array($validar);
            $_SESSION['id_admi']         = $extraido['id'];
            $_SESSION['name_admi']       = $extraido['usrname'];
            $_SESSION['email_admi']       = $extraido['email'];
            $_SESSION['tipe_admi']      = $extraido['tipe'];
            $_SESSION['avatar_admi']    = $extraido['avatar'];
            $tipe = $_SESSION['tipe_admi'];
            $bin = decbin ($tipe);
            $numlength = strlen((string)$bin);
            if($tipe != 10)
            {
                $_SESSION['v_admi'] = 0;
                $_SESSION['e_admi'] = 0;
                $_SESSION['d_admi'] = 0;
                if($numlength==1)
                {
                    $_SESSION['d_admi'] = $bin;
                }
                if($numlength==2)
                {
                    $_SESSION['v_admi'] = $bin[0];
                    $_SESSION['e_admi'] = $bin[1];
                }
                if($numlength==3)
                {
                    $_SESSION['v_admi'] =$bin[0];
                    $_SESSION['e_admi'] =$bin[1];
                    $_SESSION['d_admi'] =$bin[2];
                }
            }
            //die();
            mysqli_close($conexion);
            echo'
                <script>
                    window.location = "../dashboard.php";
                </script>
                ';
                
        }else
        {
            //die();
            $_SESSION['error_admi'] = 1;
            mysqli_close($conexion);
            echo'
                <script>
                    window.location = "../index.php";
                </script>
                ';
        }
        
        
    }
?>