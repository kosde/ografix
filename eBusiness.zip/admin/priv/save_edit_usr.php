<?php
    $conexion =  mysqli_connect("localhost","ujrujqoxugjcs","#ceudics*vd5","dbm7i5zgqipvm1");
    $name       = $_POST["name"];
    $email      = $_POST["company"];
    $pass       = $_POST["address2"];
    $id_user    = $_POST["id_user"];
    $passorginal = $_POST["address2"];
    $form_data = array();
    $v=0;
    $e=0;
    $d=0;
    if($_POST['View']=="true")
    {
        $v=1;
    }
    if($_POST['Edit']=="true")
    {
        $e=1;
    }
    if($_POST['Delete']=="true")
    {
        $d=1;
    }
 
    $permisos = bindec($v.$e.$d);
    $pass   = hash('sha512',$pass);
    $hash_email = hash('sha512',$email); 
    $form_data["View"]    = $_POST['View'];
    $form_data["Edit"]    = $_POST['Edit'];
    $form_data["Delete"]  = $_POST['Delete'];
    $form_data["tipe"]  = $permisos;
   /* if(empty($passorginal))
    {
        $query = "UPDATE users SET usrname='$name',email='$email',hash_email='$hash_email',tipe='$permisos' WHERE id = '$id_user'";
    }
    else{*/
        
    //}
    $query = "UPDATE users SET usrname='$name',email='$email',hash_email='$hash_email',pass='$pass',tipe='$permisos' WHERE id = '$id_user'";
    $verificar = mysqli_query($conexion, $query);
    $form_data["result"]  = $verificar;
    echo json_encode($form_data);
    mysqli_close($conexion); 
?>