<?php
include '../../php/conexion_be.php';
require __DIR__ . '/../../vendor/autoload.php';
require('../../php/phpmailer/class.phpmailer.php');
$datezone=date_default_timezone_get();
$date_Now = date('Y-m-d H:i');
$dateNow = DateTime::createFromFormat('Y-m-d H:i', $date_Now);
$userdata      = mysqli_query($conexion,"SELECT * FROM cart");

if(mysqli_num_rows($userdata)>0)
{
    $extraido23      = mysqli_fetch_array($userdata);
    $id            =  $extraido23['id'];
    $id_user       =  $extraido23['id_user']; 
    $dates         =  $extraido23['dates'];
    $validar  = mysqli_query($conexion,"SELECT * FROM users WHERE id='$id_user'");
    $extraido= mysqli_fetch_array($validar);
    $usrname     = $extraido ['usrname'];
    $email       = $extraido['email'];
    $date = date_create($dates);
    $total = $date->getTimestamp() - $dateNow->getTimestamp();
    $total    = gmdate("H", abs($total));
    //echo $total;
    if($total >= 8)
    {
        mysqli_query($conexion,"UPDATE cart SET dates='$date_Now' WHERE id = '$id_user'");
        $from = "info@acmestickers.com";
        
        $to = $email;
        echo $to;
        $subject = "Your cart has been saved!";
        $message = "We saved some items you left in your cart.<br>
                    <br>
                    <a href='https://acmestickers.com'>Complete your order today</a><br>
                    <br>
                    <br>
                    Acme Sticker<br>
                    <br>";

        $headers = "From: Acme Stickers <info@acmestickers.com>"  . "\r\n". "Reply-To: info@acmestickers.com" . "\r\n" . "X-Mailer: PHP/" . phpversion() . "\r\n" .
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPDebug = 1;
        $mail->Debugoutput = 'html';
        $mail->SMTPAuth = TRUE;
        $mail->SMTPSecure = "ssl";
        $mail->Port     = 465;  
        $mail->Username = "info@acmestickers.com";
        $mail->Password = "H5s8v7SeftZkK9J";
        $mail->Host     = "acmestickers.com";
        $mail->Mailer   = "smtp";
        $mail->SetFrom("orders@acmestickers.com","Acme Stickers");
        $mail->AddAddress($to);	
        $mail->Subject = $subject;
        $mail->Body    = $message;
        $mail->WordWrap   = 80;
        $mail->IsHTML(true);
        if(!$mail->Send()) {
            $msg = "<p class='error'>Problem in Sending Mail.</p>";
        } else {
            $msg = "<p class='success'>Mail Sent Successfully.</p>";
        }
    }
}

$canceled      = mysqli_query($conexion,"SELECT * FROM orders WHERE statusp='4'");
if(mysqli_num_rows($canceled)>0)
{
    //echo "canceled";
    $extraido23      = mysqli_fetch_array($canceled);
    $id            =  $extraido23['id'];
    $id_user       =  $extraido23['id_user']; 
    $dates         =  $extraido23['date_cancel'];
    if($dates != null)
    {
        //echo $dates;
        $validar  = mysqli_query($conexion,"SELECT * FROM users WHERE id='$id_user'");
        $extraido= mysqli_fetch_array($validar);
        $usrname     = $extraido ['usrname'];
        $email       = $extraido['email'];
        $date = date_create($dates);
        $total = $date->getTimestamp() - $dateNow->getTimestamp();
        $total    = gmdate("H", abs($total));
        //echo " ".$total;
        if($total >= 8)
        {
            mysqli_query($conexion,"UPDATE orders SET date_cancel=NULL WHERE id = '$id'");
            $from = "info@acmestickers.com";
            
            $to = $email;
            //echo $to;
            $subject = "Cancellation notice for order AS".$id;
            $message = "Hi ".$usrname.".<br>
                        <br>
                        Your order AS".$id." was cancelled. <br>
                        <br>
                        Order are often cancelled when only low resolution artwork is available. Altthough we send requests for better <br>
                        artwork as soon as possible.<br>
                        <br>
                        If you'd still like to proceed with this order, please reply to this email. if possible, attach higher resolution artwork in your reply.<br>
                        <br>
                        We'll reply quickly to figure out the best way forward on your order and artwork.<br>
                        <br>
                        <a href='https://acmestickers.com'>Complete your order today</a><br>
                        <br>
                        <br>
                        Thanks,<br><br>
                        Acme Sticker<br>
                        <br>";

            $headers = "From: Acme Stickers <info@acmestickers.com>"  . "\r\n". "Reply-To: info@acmestickers.com" . "\r\n" . "X-Mailer: PHP/" . phpversion() . "\r\n" .
            $headers .= "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

            $mail = new PHPMailer();
            $mail->IsSMTP();
            $mail->SMTPDebug = 1;
            $mail->Debugoutput = 'html';
            $mail->SMTPAuth = TRUE;
            $mail->SMTPSecure = "ssl";
            $mail->Port     = 465;  
            $mail->Username = "info@acmestickers.com";
            $mail->Password = "H5s8v7SeftZkK9J";
            $mail->Host     = "acmestickers.com";
            $mail->Mailer   = "smtp";
            $mail->SetFrom("orders@acmestickers.com","Acme Stickers");
            $mail->AddAddress($to);	
            $mail->Subject = $subject;
            $mail->Body    = $message;
            $mail->WordWrap   = 80;
            $mail->IsHTML(true);
            if(!$mail->Send()) {
                $msg = "<p class='error'>Problem in Sending Mail.</p>";
            } else {
                $msg = "<p class='success'>Mail Sent Successfully.</p>";
            }
        }
    }
}


mysqli_close($conexion);

?>