<?php
    session_start();
    $datezone=date_default_timezone_get();
    $name       = $_POST["name"];
    $email      = $_POST["company"];
    $pass       = $_POST["address2"];
    $v=0;
    $e=0;
    $d=0;
    if($_POST['View']=="true")
    {
        $v=1;
    }
    if($_POST['Edit']=="true")
    {
        $e=1;
    }
    if($_POST['Delete']=="true")
    {
        $d=1;
    }
    $permisos = bindec($v.$e.$d);
    $pass   = hash('sha512',$pass);
    $hass_email = hash('sha512',$email); 
    include "conexion_be.php";
    $verificar1 = mysqli_query($conexion, "SELECT * FROM users WHERE email='$email'");
    $verificar = mysqli_query($conexion, "SELECT * FROM users WHERE usrname='$name'");
    
    if(mysqli_num_rows($verificar1)==0 && mysqli_num_rows($verificar)==0)
    {
        $query_address = "INSERT INTO users (usrname,    email,      pass,   tipe, hash_email )
                            VALUES         ('$name',  '$email',   '$pass', '$permisos','$hass_email')";
        $address_result = mysqli_query($conexion,$query_address);
    }
    else {
        $_SESSION['errorU_admi'] = 1;
    }
    mysqli_close($conexion); 
    echo'
    <script>
        window.location = "../account.php";
    </script>
    ';
?>