<?php
    $conexion =  mysqli_connect("ografix.com","ografix2_dash","+vTlFRJ}AB~c","ografix2_admin");
    /*if($conexion){
        echo 'conectado';
    }else
    {
        echo 'no conectado';
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }*/
?>