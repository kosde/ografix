<?php
    session_start();
    include 'conexion_be.php';
    $id  = $_POST['id'];
    $form_data = array();
    $validar  = mysqli_query($conexion,"SELECT * FROM users WHERE id='$id' AND id!='1'");
    if(mysqli_num_rows($validar)>0)
    {
        $extraido= mysqli_fetch_array($validar);
        $form_data["usrname"]=$extraido["usrname"];
        $form_data["email"]=$extraido['email'];
        $form_data["tipe"]=$extraido['tipe'];
        $tipe = $extraido['tipe'];
        $bin = decbin ($tipe);
        $numlength = strlen((string)$bin);
        if($tipe != 10)
        {
            $_SESSION['v_admi'] = 0;
            $_SESSION['e_admi'] = 0;
            $_SESSION['d_admi'] = 0;
            if($numlength==1)
            {
                $_SESSION['d_admi'] = $bin;
            }
            if($numlength==2)
            {
                $_SESSION['v_admi'] = $bin[0];
                $_SESSION['e_admi'] = $bin[1];
            }
            if($numlength==3)
            {
                $_SESSION['v_admi'] =$bin[0];
                $_SESSION['e_admi'] =$bin[1];
                $_SESSION['d_admi'] =$bin[2];
            }
            $form_data["v_admi"]=$_SESSION['v_admi'];
            $form_data["e_admi"]=$_SESSION['e_admi'];
            $form_data["d_admi"]=$_SESSION['d_admi'];
        }
        
        mysqli_close($conexion);
        echo json_encode($form_data);
    }
?>