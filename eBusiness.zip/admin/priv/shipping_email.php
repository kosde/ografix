<?php
    $email     = $_POST["email"];
    $name     = $_POST["name"];
    $id_user    = $_POST["id_user"];
    $traking_n = $_POST["traking_n"];
    $id_order  = $_POST["id_order"];
    require __DIR__ . '/../../vendor/autoload.php';
    use Twilio\Rest\Client;
    require('../../php/phpmailer/class.phpmailer.php');
    include "../../php/conexion_be.php";
    $activar = mysqli_query($conexion,"UPDATE orders SET statusp = '8',guie='$traking_n' WHERE id = '$id_order'");
    if(mysqli_affected_rows($conexion) == 1)
    {
        $from = "info@acmestickers.com";
        $to = $email;
        
        $subject = "Order status";
        $message = "Hi ". $name .",<br>
                    <br>
                    Your order has been shipped and is in the hands of the carrier. <br>
                    Your traking number is ".$traking_n.".<br>
                    <a href='https://acmestickers.com/traking.php?order=".$id_order."&traking=".$traking_n."'>Click here</a><br>
                    <br>
                    <br>
                    Thanks,<br><br>
                    Acme Sticker<br>
                    <br>
                    <!DOCTYPE html>
                    <html lang='es'>
                    <head>
                        <meta charset='utf-8'>
                        <title>Reset your password</title>
                    </head>
                    <body>
                    <table style='max-width: 800px; padding: 10px; margin:0 auto; border-collapse: collapse;'>
                        <tr>
                            <td>
                                <div style='color: #34495e; margin: 4% 4% 2%; text-align: justify;font-family: sans-serif'>                                                                  
                                    <table class='x_w220 x_textcenter' cellspacing='0' cellpadding='0' border='0' align='center'>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <img style='width: 100%;' data-imagetype='External' src='https://www.acmestickers.com/assets/traking/shipped.png'> 
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </td>
                        </tr>
                    </table>
                    </body>
                    </html>";
        /*
        $headers = "From: Acme Stickers <info@acmestickers.com>"  . "\r\n". "Reply-To: info@acmestickers.com" . "\r\n" . "X-Mailer: PHP/" . phpversion() . "\r\n" .
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
         <a href='http://wwwapps.ups.com/WebTracking/track?track=yes&trackNums=".$traking_n."'>Click here</a><br>*/

        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPDebug = 1;
        $mail->Debugoutput = 'html';
        $mail->SMTPAuth = TRUE;
        $mail->SMTPSecure = "ssl";
        $mail->Port     = 465;  
        $mail->Username = "info@acmestickers.com";
        $mail->Password = "H5s8v7SeftZkK9J";
        $mail->Host     = "acmestickers.com";
        $mail->Mailer   = "smtp";
        $mail->SetFrom("orders@acmestickers.com","Acme Stickers");
        $mail->AddAddress($to);	
        $mail->Subject = $subject;
        $mail->Body    = $message;
        $mail->WordWrap   = 80;
        $mail->IsHTML(true);
        if(!$mail->Send()) {
            $msg = "<p class='error'>Problem in Sending Mail.</p>";
        } else {
            $msg = "<p class='success'>Mail Sent Successfully.</p>";
        }
        //mail($to,$subject,$message, $headers);
        /*mail($to,$subject,$message, $headers);*/
        $userdata      = mysqli_query($conexion,"SELECT * FROM users WHERE id='$id_user'");
        if(mysqli_num_rows($userdata)>0)
        {
            //deals_browser 	deals_sms 	deals_email 	alerts_sms 	alerts_email 	proofing_sms 	proofing_email 
            $extraido23      = mysqli_fetch_array($userdata);
            $usrname           =  $extraido23['usrname'];
            $phone           =  $extraido23['phone'];
            $code            =  $extraido23['code'];
        }
        $notif      = mysqli_query($conexion,"SELECT * FROM notifications WHERE id_user='$id_user'");
        if(mysqli_num_rows($notif)>0)
        {
            //deals_browser 	deals_sms 	deals_email 	alerts_sms 	alerts_email 	proofing_sms 	proofing_email 
            $extraido2      = mysqli_fetch_array($notif);
            $id_n           =  $extraido2['id'];
            $id_usern       =  $extraido2['id_user'];
            $deals_browser  =  $extraido2['deals_browser'];
            $deals_sms      =  $extraido2['deals_sms'];
            $deals_email    =  $extraido2['deals_email'];
            $alerts_sms     =  $extraido2['alerts_sms'];
            $alerts_email   =  $extraido2['alerts_email'];
            $proofing_sms   =  $extraido2['proofing_sms'];
            $proofing_email =  $extraido2['proofing_email'];
        }
        $sms_txt = "Hi ". $name .",\n\nYour order has been shipped and is in the hands of the carrier\nYour traking number is ".$traking_n."\n\nhttps://acmestickers.com/traking.php?order=".$id_order."&traking=".$traking_n.".\n\n\nThanks,\nAcme Sticker";
        //$sms_txt = "Hi ". $usrname .", \n\nYour order AS".$id_order." is printing (or in the queue to be printed very soon).\n\n\nAcme Sticker";
        
        if($proofing_sms==1)
        {
            $sDestination ="+".$code.$phone;
            $account_sid = 'ACddfb48d031bf54554a1e68221e105f4f';
            $auth_token = 'a24a7c2cc899eb2d8d7749ced756ed8d';
            $twilio_number = "+12052739743";

            $client = new Client($account_sid, $auth_token);
            $client->messages->create(
                $sDestination,
                array(
                    'from' => $twilio_number,
                    'body' => $sms_txt
                )
            );
        }

        mysqli_close($conexion);
            echo'
            <script>
                window.location = "../notifications.php";
            </script>
            ';
    }
?>