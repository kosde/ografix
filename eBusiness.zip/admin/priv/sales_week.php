<?php
session_start();
include "../../php/conexion.php";
$id  = $_POST['id_user'];/*
$form_data = array();
$form_data['success'] = "no";*/
//$form_data[1]  = "1";
//$query  = "SELECT price, COUNT(price) FROM orders WHERE dates BETWEEN GETDATE() AND DATEADD(day, -7, GETDATE()) GROUP BY orders";
$month = date('Y');
$query2 = "SELECT year(dates) as y, month(dates) as m, sum(price) as p from orders WHERE YEAR(dates) ='$month' group by year(dates), month(dates)";
//$query3 = "SELECT MONTH(dates) as SalesMonth,SUM(price) AS TotalSales FROM orders WHERE dates BETWEEN GETDATE() AND DATEADD(day, -7, GETDATE()) GROUP BY orders ";
$validar  = mysqli_query($conexion,"SELECT DAYNAME(dates) as WeeksDay, COUNT(id) as counta FROM orders O GROUP BY DAYNAME(dates) ORDER BY DAYNAME(dates)");
$cont = 1;
if(mysqli_num_rows($validar)>0)
{
    while($extraido= mysqli_fetch_array($validar))
    {
        $form_data[$extraido["WeeksDay"]]=$extraido["counta"];
    }
    mysqli_close($conexion);
}
echo json_encode($form_data);
?>