<?php
session_start();
include "../../php/conexion.php";
$id  = $_POST['id_user'];
$form_data = array();
$month = date('Y');
$validar  = mysqli_query($conexion,"SELECT tipe as namep,count(id) as cont from orders WHERE YEAR(dates) ='$month' group by tipe");
$cont = 1;

if(mysqli_num_rows($validar)>0)
{
    while($extraido= mysqli_fetch_array($validar))
    {
        
        $form_data[$extraido['namep']]=$extraido['cont'];
        $cont++;
    }
    mysqli_close($conexion);
}
echo json_encode($form_data);
?>