<?php
session_start();
include 'conexion_be.php';
$id  = $_POST['id'];
$validar  = mysqli_query($conexion,"SELECT * FROM users WHERE id='$id'");
if(mysqli_num_rows($validar)>0)
{
    $extraido   = mysqli_fetch_array($validar);
    $usrname    = $extraido["usrname"];
    $email      = $extraido['email'];
    $tipe       = $extraido['tipe'];
    $to         = $email;


    $subject = "Activacion de cuenta";
    $subject = "=?UTF-8?B?".base64_encode($subject)."=?=";
    $message = "Hola ". $name ."<br>
                <br>
                Para poder completar tu registro da click en el siguiente link:<br>
                <br>
                <a href='". $linkverifica ."'>". $linkverifica ."</a><br>
                <br>
                <br>
                Saludos,<br>
                <br>
                ografix";
    require('phpmailer/class.phpmailer.php');
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPDebug = 1;
    $mail->Debugoutput = 'html';
    $mail->SMTPAuth = TRUE;
    $mail->SMTPSecure = "ssl";
    $mail->Port     = 465;  
    $mail->Username = "notificaciones@ografix.com";
    $mail->Password = "tlk3QOsEuN2.";
    $mail->Host     = "mail.ografix.com";
    $mail->Mailer   = "smtp";
    $mail->SetFrom("notificaciones@ografix.com","ografix");
    $mail->AddAddress($to);	
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->WordWrap   = 80;
    $mail->CharSet = 'UTF-8';
    $mail->IsHTML(true);
    if(!$mail->Send())
    {
        //echo "Problem in Sending Mail";
    }
    else 
    {
    
        //echo "Mail Sent Successfully";
    }
}
mysqli_close($conexion);
?>