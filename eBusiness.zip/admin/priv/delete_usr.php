<?php
session_start();
$id     = $_POST["id"];
//$conexion =  mysqli_connect("localhost","u4g4jzvgram6g","^(3@uzE24H3C","db8qd64hszcs9u");
include "../../php/conexion.php";
$address_result = mysqli_query($conexion,"DELETE FROM users WHERE id ='$id'");
$address_result = mysqli_query($conexion,"SELECT * FROM orders WHERE id ='$id'");
if(mysqli_num_rows($address_result)>0)
{
    while ($extraido = mysqli_fetch_array($address_result))
    {
        $id_orders   = $extraido['id_orders'];
        $id_images   = $extraido['id_images'];
        $R1 = mysqli_query($conexion,"DELETE FROM orders WHERE id_images ='$id_images'");
        $R2 = mysqli_query($conexion,"DELETE FROM coments WHERE id_orders ='$id_orders'");
    }
}
$address_result = mysqli_query($conexion,"DELETE FROM orders WHERE id_user ='$id'");
$address_result = mysqli_query($conexion,"DELETE FROM notifications WHERE id_user ='$id'");
$address_result = mysqli_query($conexion,"DELETE FROM cart WHERE id_user ='$id'");
$address_result = mysqli_query($conexion,"DELETE FROM billing_address WHERE id_user ='$id'");
$address_result = mysqli_query($conexion,"DELETE FROM artworks WHERE id_user ='$id'");
$address_result = mysqli_query($conexion,"DELETE FROM address_t WHERE id_user ='$id'");
$address_result = mysqli_query($conexion,"DELETE FROM coments WHERE id_user ='$id'");
$address_result = mysqli_query($conexion,"DELETE FROM images WHERE id_user ='$id'");
mysqli_close($conexion); //$delivery_date  = $_GET["deliverytime"];
echo'
<script>
    window.location = "../account.php";
</script>
';
?>