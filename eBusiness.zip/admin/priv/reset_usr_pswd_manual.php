<?php
session_start();
include "../../php/conexion_be.php";
$id  = $_POST['id_user'];
//$newpswd = "RdQijZT82py4yPP";
$str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
$password = "";
for($i=0;$i<10;$i++) {
    $password .= substr($str,rand(0,62),1);
}
$pass_u   = hash('sha512',$password);
$activar = mysqli_query($conexion,"UPDATE users SET pass = '$pass_u' WHERE id = '$id'");
if(mysqli_affected_rows($conexion))
{
    $validar  = mysqli_query($conexion,"SELECT * FROM users WHERE id='$id'");
    if(mysqli_num_rows($validar)>0)
    {
        $extraido= mysqli_fetch_array($validar);
        $id          = $extraido['id'];
        $temporal    = $extraido['temporal'];
        $date_create = $extraido['date_create'];
        $active      = $extraido ['active'];
        $usrname     = $extraido['usrname'];
        $pass        = $extraido ['pass'];
        $email       = $extraido['email'];
        $hash_email  = $extraido ['hash_email'];
        $code        = $extraido['code'];
        $phone       = $extraido ['phone'];
        $avatar      = $extraido['avatar'];
        $admi        = $extraido['admi'];
        mysqli_close($conexion);
    }
    mysqli_close($conexion);
    $from = "info@acmestickers.com";
    $to = $email;
    $cadena2="US";
    if(strcmp ($cadena2 , $country_id ) == 0)
    {
        $country_id='United States';
    }
    $subject = "Reset your password";
    $message = "Hi ". $usrname .",<br>
             
                ";
    $message = "Hi ". $usrname .",<br>
                We created the next temporary password for you to sign in, but we recommend that you change this password  ". $password ."  <br>
                Thanks,<br>
                Acme Sticker";
    $headers = "From: Acme Stickers <info@acmestickers.com>"  . "\r\n". "Reply-To: info@acmestickers.com" . "\r\n" . "X-Mailer: PHP/" . phpversion() . "\r\n" .
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
    mail($to,$subject,$message, $headers);
}
?>