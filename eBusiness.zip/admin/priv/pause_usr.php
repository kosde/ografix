<?php
    $num        = $_POST["num"];
    $id_user    = $_POST["id_user"];
   
    $conexion =  mysqli_connect("localhost","ujrujqoxugjcs","#ceudics*vd5","dbm7i5zgqipvm1");
    $activar = mysqli_query($conexion,"UPDATE users SET admi  = '$num' WHERE id = '$id_user'");
    if(mysqli_affected_rows($conexion) == 1)
    {
        mysqli_close($conexion);
    }
?>