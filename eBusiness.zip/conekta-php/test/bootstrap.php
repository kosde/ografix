
<?php
require_once __DIR__ . '/../lib/Conekta.php';
require_once __DIR__ . '/BaseTest.php';

$validCustomer = [
    'name' => "Payment Link Name",
    'email' => "Juan Perez"
];
$customer = Customer::create($validCustomer);
echo $customer->livemode;
echo $customer->name;
echo $customer->email;
echo $customer->id;
echo $customer->object;