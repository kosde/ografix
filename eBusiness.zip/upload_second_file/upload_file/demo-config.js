$(function(){
  $('#drag-and-drop-zone_2').dmUploader({ // 
    onDragEnter: function(){
      // Happens when dragging something over the DnD area
      this.addClass('activedrop');
      document.getElementById("formdrop_2").style.opacity = "0";
    },
    onDragLeave: function(){
      // Happens when dragging something OUT of the DnD area
      this.removeClass('activedrop');
      console.log("removeclass");
      document.getElementById("formdrop_2").style.opacity = "1";
    },
    onInit: function(){
      // Plugin is ready to use
      ui_add_log('Penguin initialized :)', 'info');
    },
    onComplete: function(){
      // All files in the queue are processed (success or error)
      ui_add_log('All pending tranfers finished');
    },
    onNewFile: function(id, file){
      // When a new file is added using the file selector or the DnD area
      fileobj2 = file;
      document.getElementById('file-name_2').value = file.name;
      if(document.getElementById('comments_2'))
      {
        document.getElementById('comments_2').style.visibility = 'visible';
        document.getElementById('comments_2').style.display = 'block';
        var reader = new FileReader();
        reader.readAsDataURL(file );
        reader.onloadend = function () {
          document.getElementById("proof_image_2").src = reader.result;
        }
      }
    },
  });
});