<?php
  $conexion =  mysqli_connect("ografix.com","ografix2_admin","b9011m[h5D_#","ografix2_ografix");
  /*if($conexion){
      echo 'conectado';
  }else
  {
      echo 'no conectado';
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }*/
?>