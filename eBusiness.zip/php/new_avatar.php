<?php
session_start();
include 'conexion.php';
$nombre = $_POST['file-name'];
$file   = $_FILES['Imagen']['tmp_name'];
$id     = $_SESSION['id'];

$image = addslashes(file_get_contents($_FILES['Imagen']['tmp_name'])); 
$activar = mysqli_query($conexion,"UPDATE users SET avatar = '$image' WHERE id = '$id'");
$validar  = mysqli_query($conexion,"SELECT * FROM users WHERE id='$id'");
$extraido= mysqli_fetch_array($validar);
$_SESSION['avatar']     = $extraido['avatar'];
mysqli_close($conexion);
echo'
            <script>
                window.location = "../perfil";
            </script>
            ';
            
?>