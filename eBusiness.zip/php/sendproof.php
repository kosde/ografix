<?php
include 'conexion.php';
require __DIR__ . '/../vendor/autoload.php';
use Twilio\Rest\Client;
$link       = $_POST['link'];
$coment     = $_POST['coment'];
$id_order   = $_POST['id_order'];
$email      = $_POST['email'];
$name       = $_POST['name'];
$code       = $_POST['code'];
$phone      = $_POST['phone'];//id_user
$id_user    = $_POST['id_user'];
$link2      = $_POST['link2'];
$basename   = $_POST['basename'];
//$parte = explode(".png", $link);

/*mysqli_query($conexion,"UPDATE orders SET statusp = '1' WHERE id='$id_order'");
$proof      = mysqli_query($conexion,"SELECT * FROM notifications WHERE id_user='$id_user'");
if(mysqli_num_rows($proof)>0)
{
    //deals_browser 	deals_sms 	deals_email 	alerts_sms 	alerts_email 	proofing_sms 	proofing_email 
    $extraido2      = mysqli_fetch_array($proof);
    $id_n           =  $extraido2['id'];
    $id_usern       =  $extraido2['id_user'];
    $deals_browser  =  $extraido2['deals_browser'];
    $deals_sms      =  $extraido2['deals_sms'];
    $deals_email    =  $extraido2['deals_email'];
    $alerts_sms     =  $extraido2['alerts_sms'];
    $alerts_email   =  $extraido2['alerts_email'];
    $proofing_sms   =  $extraido2['proofing_sms'];
    $proofing_email =  $extraido2['proofing_email'];
}
*/
$linkverifica = "https://www.ografix.com/prueba?order=".$id_order;
/*$sms_txt = "Your Acme Sticker proof is ready to be reviewed! \n\n" .$linkverifica." ";

if($proofing_sms==1)
{
    $sDestination ="+".$code.$phone;
    $account_sid = 'ACddfb48d031bf54554a1e68221e105f4f';
    $auth_token = 'a24a7c2cc899eb2d8d7749ced756ed8d';
    $twilio_number = "+12052739743";

    $client = new Client($account_sid, $auth_token);
    $client->messages->create(
        $sDestination,
        array(
            'from' => $twilio_number,
            'body' => $sms_txt
        )
    );
}*/
/*
    if($proofing_sms==1)
    {
        $sDestination ='+'.$code.$phone;
        require __DIR__ . '/../vendor/autoload.php';
        use Twilio\Rest\Client;

        // Your Account SID and Auth Token from twilio.com/console
        $account_sid = 'ACddfb48d031bf54554a1e68221e105f4f';
        $auth_token = 'a24a7c2cc899eb2d8d7749ced756ed8d';
        // In production, these should be environment variables. E.g.:
        // $auth_token = $_ENV["TWILIO_AUTH_TOKEN"]

        // A Twilio number you own with SMS capabilities
        $twilio_number = "+12052739743";

        $client = new Client($account_sid, $auth_token);
        $client->messages->create(
            // Where to send a text message (your cell phone?)
            $sDestination,
            array(
                'from' => $twilio_number,
                'body' => "Your Acme Sticker proof is ready to be reviewed! '. $linkverifica .'"
            )
        );
    }
*/
$correo = -1;
$date = date('Y-m-d H:i');
$src="";
if($link!="" && $coment!="" || $link=="" && $coment!="" || $link!="" && $coment=="")
{   
    if($coment=="")
    {
        $$coment = "Created proof";
    }
    $extension = pathinfo($basename , PATHINFO_EXTENSION);
    $link = str_replace(".".$extension,"", $link);
    $query_coment_acme = "INSERT INTO coments (id_orders, coment_usr,      coment_client, 	date_coment, link, put)
                                        VALUES('$id_order',    '$coment',        '1'        ,'$date'  ,'$link','1')";
    $correo = 0;
    $src = $link;
}
else{
    $query_coment_acme = "UPDATE coments SET put = '1' WHERE id_orders = '$id_order'";
    $correo = 1;
    $src = $link2;
}
$verificar_coment_Acme = mysqli_query($conexion, $query_coment_acme);

$from = "info@acmestickers.com";
$to = $email;

$subject = "Tu prueba esta lista";
$message = "Hola ". $name .",<br>
            <br>
            Tu prueba esta lista <a href='". $linkverifica ."'>GRFX$id_order.</a> para ser revisada<br>
            <br>
            <a href='". $linkverifica ."'>Confirma de aprobado o solicita cambios</a><br>
            <br>
            Cuando todo está aprobado, enviaremos tu orden a impresión.<br>
            <br>
            Gracias<br>
            <br>
            <br>
            ografix<br>
            ";         

require('phpmailer/class.phpmailer.php');

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 1;
$mail->Debugoutput = 'html';
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = "ssl";
$mail->Port     = 465;  
$mail->Username = "notificaciones@ografix.com";
$mail->Password = "tlk3QOsEuN2.";
$mail->Host     = "mail.ografix.com";
$mail->Mailer   = "smtp";
$mail->SetFrom("notificaciones@ografix.com","ografix");
$mail->AddAddress($to);	
$mail->Subject = $subject;
$mail->Body    = $message;
$mail->WordWrap   = 80;
$mail->CharSet = 'UTF-8';
$mail->IsHTML(true);
if(!$mail->Send()) {
    $msg = "<p class='error'>Problem in Sending Mail.</p>";
} else {
    $msg = "<p class='success'>Mail Sent Successfully.</p>";
}

mysqli_close($conexion);
?>