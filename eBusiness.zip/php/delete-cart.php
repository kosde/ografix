<?php
session_start();
include 'conexion.php';
$id_image = $_GET["id-image"];
$id_cart= $_GET["id-cart"];
$query_cart = "DELETE FROM cart WHERE id = '$id_cart'";
$query_image = "DELETE FROM images WHERE id = '$id_image'";
$verificar_cart = mysqli_query($conexion,$query_cart);
if($verificar_cart)
{
    $verificar_images = mysqli_query($conexion,$query_image);
    if($verificar_images)
    {
        echo'
            <script>
                window.location = "../carrito";
            </script>
            ';
        mysqli_close($conexion);
        exit();
    }
}
mysqli_close($conexion);
?>