<?php
    session_start();
    include 'conexion.php';
    $email      = $_GET['email'];
    $pass     = $_POST['password'];
    $pass_u     = hash('sha512',$pass);
    $query      = "SELECT * FROM users WHERE hash_email='$email'";
    $validar = mysqli_query($conexion,$query);
    if(mysqli_num_rows($validar)>0)
    {
        $activar = mysqli_query($conexion,"UPDATE users SET pass = '$pass_u' WHERE hash_email = '$email'");
        if(mysqli_affected_rows($conexion))
        {
            mysqli_close($conexion);
            session_destroy();
            session_start();
            $_SESSION["error"] = 4;
            echo'
            <script>
                window.location = "../identificate";
            </script>
            ';
           
            exit();
        }
        else{
            $_SESSION["error"] = 5;
            echo'
                <script>
                    window.location = "../identificate";
                </script>
                ';
        }
        
    }
    else
    {
        $_SESSION["error"] = 3;
        echo'
                <script>
                    window.location = "../identificate";
                </script>
                ';
    }
    
?>