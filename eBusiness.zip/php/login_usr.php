<?php
    session_start();
    include 'conexion.php';
    $email_u  = $_POST['correo'];
    $form_data = array();
    $pass_u   = $_POST['pass'];
    $pass_u   = hash('sha512',$pass_u);
    $form_data['e_login'] = null;
    $validar2  = mysqli_query($conexion,"SELECT * FROM users WHERE email='$email_u'");
    if(mysqli_num_rows($validar2)==0)
    {
        $form_data['e_login'] = 1;
    }
    $validar  = mysqli_query($conexion,"SELECT * FROM users WHERE email='$email_u' and pass='$pass_u'");
    if(mysqli_num_rows($validar)>0)
    {
        $extraido= mysqli_fetch_array($validar);
        $_SESSION['id']         = $extraido['id'];
        //$_SESSION['tipo']       = $extraido ['tipo'];
        $_SESSION['date_create']= $extraido['date_create'];
        $_SESSION['active']     = $extraido['active'];
        $_SESSION['usrname']    = $extraido['usrname'];
        $_SESSION['pass']       = $extraido['pass'];
        $_SESSION['email']      = $extraido['email'];
        $_SESSION['hash_email'] = $extraido['hash_email'];
        $_SESSION['code']       = $extraido['code'];
        $_SESSION['phone']      = $extraido['phone'];
        $_SESSION['avatar']     = $extraido['avatar'];
        $_SESSION['documento']  = $extraido['documento'];
        $_SESSION['documentoN'] = $extraido['documentoN'];
        $_SESSION['id_address'] = $extraido['id_address'];
        $_SESSION['id_orders']  = $extraido['id_orders'];
        $_SESSION['id_billing'] = $extraido['id_billing'];
        $_SESSION['company']    = $extraido['company'];
        $_SESSION['admi']       = $extraido['admi'];
        $_SESSION['RFC']        = $extraido['RFC'];
        //$_SESSION['temporal']   = $extraido['temporal'];
        $temporal = $extraido['temporal'];
        if($temporal == 0) //temporal usado activar el tipo de usuario
        {
            $_SESSION['tipo'] = 0;
            $_SESSION['temporal'] = 0;
        }
        if($temporal == 1) 
        {
            $_SESSION['tipo'] = 1;
            $_SESSION['temporal'] = 1;
        }
        $form_data['e_login'] = 3;
        $_SESSION["e_login"] = 3;
        if($_SESSION['admi']==0)
        {
            
            session_destroy();
            session_start();
            $form_data['e_login'] = 4;
            $_SESSION["error"] = 2;
            /*echo'
                <script>
                    window.location = "../identificate";
                </script>
                '; 
            */  
        }
        /*echo'
            <script>
                window.location = "../index?msg=Signed in successfully";
            </script>
            ';
        */
    }else{
        $_SESSION["error"] = 1;
        $form_data['e_login']=2;
        /*echo'
            <script>
                window.location = "../identificate";
            </script>
            '; 
        */
    }
    mysqli_close($conexion);
    if(isset($_POST['identificate']))
    {
        echo'
            <script>
                window.location = "../index";
            </script>
            ';
    }
    else
    {
        echo json_encode($form_data);
        return;
    }
?>