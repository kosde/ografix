<?php
$full_name   = $_POST["name"];
$email       = $_POST["email"];
$subject     = $_POST["subject"];
$message     = $_POST["message"];
$link        = $_POST["link"];
$dates       = date('Y-m-d H:i:s');
$from = $email;
//$to ="angel_0_6@live.com.mx";
$to = "ografix@gmail.com";
$subject = "Correo de Contacto";
$messageF = $subject . " <br> " . $message . " <br> " . $email;
$headers = "From: ".$to." <".$to.">"  . "\r\n". "Reply-To: ".$to."" . "\r\n" . "X-Mailer: PHP/" . phpversion() . "\r\n" .
$headers .= "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

mail($to,$subject,$messageF, $headers);

$linkverifica = $link;
$subject = "Cotizacion";
$message = "Hola <br>
            <br>
            Para poder completar tu registro da click en el siguiente link:<br>
            <br>
            <a href='". $linkverifica ."'>". $linkverifica ."</a><br>
            <br>
            <br>
            Saludos,<br>
            <br>
            ografix";
require('phpmailer/class.phpmailer.php');
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 1;
$mail->Debugoutput = 'html';
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = "ssl";
$mail->Port     = 465;  
$mail->Username = "notificaciones@ografix.com";
$mail->Password = "tlk3QOsEuN2.";
$mail->Host     = "mail.ografix.com";
$mail->Mailer   = "smtp";
$mail->SetFrom("notificaciones@ografix.com","ografix");
$mail->AddAddress($to);	
$mail->Subject = $subject;
$mail->Body    = $message;
$mail->WordWrap   = 80;
$mail->CharSet = 'UTF-8';
$mail->IsHTML(true);
if(!$mail->Send())
{
    //echo "Problem in Sending Mail";
}
else 
{
    //echo "Mail Sent Successfully";
}
?>