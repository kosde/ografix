<?php
    session_start();
    $emailU  = $_POST['email'];
    include 'conexion.php';
    $validar  = mysqli_query($conexion,"SELECT * FROM users WHERE email='$emailU'");
    if(mysqli_num_rows($validar)>0)
    {
        $_SESSION['recoverpass'] = "exite";
        if($emailU)
        {
            $datezone=date_default_timezone_get();
            $date = date('Y-m-d H:i');
            $date_hash =  hash('sha512',$date);
            $activar = mysqli_query($conexion,"UPDATE users SET date_token='$date',token='$date_hash' WHERE email = '$emailU'");
            $from = "notificaciones@ografix.com";
            $to = $emailU;
            $linkverifica = "https://www.ografix.com/nueva_contrasena?email=".hash('sha512',$emailU)."&token=".$date_hash;
            $subject = "Recuperación de contraseña";
            $subject = "=?UTF-8?B?".base64_encode($subject)."=?=";
            /*$message = "<!DOCTYPE html>
                        <html lang='es'>
                        <head>
                            <meta charset='utf-8'>
                            <title>Reset your password</title>
                        </head>
                        <body style='background-color: white'>
                        <table style='max-width: 800px; padding: 10px; margin:0 auto; border-collapse: collapse;'>
                            <tr>
                                <td style='background-color: #ecf0f1'>
                                    <div style='color: #34495e; margin: 4% 4% 2%; text-align: justify;font-family: sans-serif'>
                                        <h2 style='color: #000; margin: 0 0 7px'>We heard you lost your password. </h2>
                                        <p style='margin: 2px; font-size: 15px'>
                                            Click the button below to choose a new password:<br>
                                        </p>
                                        <br>
                                        <br>
                                        <br>
                                        
                                        <table class='x_w220 x_textcenter' cellspacing='0' cellpadding='0' border='0' bgcolor='#f87060' align='center'>
                                            <tbody><tr><td width='2' bgcolor='#f87060'>
                                                <img data-imagetype='External' src='' class='x_hide' alt='' width='2' height='69'> 
                                                </td>
                                                <td width='424' height='80' align='center'>
                                                    <p class='x_fontCTA' style='font-size:19px; color:#ffffff; letter-spacing:0.5px; font-weight:400;text-align: center;'>
                                                    <a href=\"". $linkverifica ."\" target='_blank' rel='noopener noreferrer' data-auth='NotApplicable' style='text-decoration:none; color:#ffffff' data-linkindex='0'>
                                                    Reset password
                                                    </a>
                                                    </p>
                                                </td>
                                                <td width='2' bgcolor='#f87060'><img data-imagetype='External' src='' class='x_hide' alt='' width='2' height='69'>
                                                </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        
                                        <br>
                                        <br>
                                        <br>
                                        <p style='margin: 2px; font-size: 15px'>
                                            If you did not request a password reset, please ignore this email.<br>
                                            <br>
                                            <br>
                                            <br>
                                            Thanks,<br>
                                            <br>
                                            Acme Sticker
                                        </p>
                                        <p style='color: darkslategray; font-size: 13px; text-align: center;margin: 30px 0 0'>Need help? Write us to help@acmestickers.com</p>
                                    </div>
                                </td>
                            </tr>
                        </table>
                        </body>
                        </html>
            ";*/
            $message = "Recibimos la solicitud para cambiar la contraseña de tu cuenta<br>
                                        <br>
                                        Haz clic en el siguiente link para iniciar este proceso.<br>
                                        <br>
                                        <a href='". $linkverifica ."'>Cambiar ahora</a><br>
                                        <br>
                                        Si no solicitaste el cambio de contraseña ignora este correo<br>
                                        <br>
                                        <br>
                                        <br>
                                        Saludos,<br>
                                        <br>
                                        ografix";
            require('phpmailer/class.phpmailer.php');

            $mail = new PHPMailer();
            $mail->IsSMTP();
            $mail->SMTPDebug = 1;
            $mail->Debugoutput = 'html';
            $mail->SMTPAuth = TRUE;
            $mail->SMTPSecure = "ssl";
            $mail->Port     = 465;  
            $mail->Username = "notificaciones@ografix.com";
            $mail->Password = "tlk3QOsEuN2.";
            $mail->Host     = "mail.ografix.com";
            $mail->Mailer   = "smtp";
            $mail->SetFrom("notificaciones@ografix.com","ografix");
            $mail->AddAddress($to);	
            $mail->Subject = $subject;
            $mail->Body    = $message;
            $mail->WordWrap = 80;
            $mail->IsHTML(true);
            $mail->CharSet = 'UTF-8';
            if(!$mail->Send()) {
                $msg = "<p class='error'>Problem in Sending Mail.</p>";
            } else {
                $msg = "<p class='success'>Mail Sent Successfully.</p>";
            }
        }
        unset ($_SESSION["error"]);
        header("Location: ../reset?email=$emailU");
        exit();
    }
    else
    {
        $_SESSION['error']=3;
        header("Location: ../identificate");
    }
?>