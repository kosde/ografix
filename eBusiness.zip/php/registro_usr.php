<?php
    session_start();
    $datezone=date_default_timezone_get();
    include 'conexion.php';
    $form_data = array(); 
    $form_data['error'] = "null";
    $name       = $_POST['name'];
    $email      = $_POST['email'];
    $pass1      = $_POST['pass1'];
    $address1   = $_POST['address1']; //falta
    $address2   = $_POST['address2'];//falta
    $locality   = $_POST['locality'];//falta
    $zipcode    = $_POST['zipcode'];//falta
    $state      = $_POST['state'];//falta
    $RFC        = $_POST['RFC']; 
    $company    = $_POST['company'];
    $code       = $_POST['code'];
    $phone      = $_POST['phone'];
    $file_name  = $_FILES['file']['name'];
    $country    = $_POST['country'];
    
    if(empty($file_name))
    {
        $image = null;
        $file_name = null;  
    }
    $file_name = $_FILES['file']['name'];
    $image = addslashes(file_get_contents($_FILES['file']['tmp_name'])); 
    
    $verificar = mysqli_query($conexion, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($verificar)>0)
    {
        $form_data['error'] = "1";
        mysqli_close($conexion);
        return;
    }
    else
    {

    
        $pass_u = hash('sha512',$pass1);
        $hash_email = hash('sha512',$email);
        $date = date('Y-m-d H:i');
        if(isset($_POST['comercial']) && $_POST['comercial'] !=0)
        {
            $tipo = 0;
        }
        if(isset($_POST['maquila']) && $_POST['maquila']!=0)
        {
            $tipo = 1;
        }
        $tipo_negocio = "";
        if($tipo == 1)
        {
            $admi = 0;
        }
        else{
            $admi = 1;
        }
        if(isset($_POST['tipe_negocio']) && $_POST['tipe_negocio']!="")
        {
            $tipo_negocio = $_POST['tipe_negocio'];
            if(isset($_POST['otro_negocio']) && $_POST['otro_negocio']!="" && $_POST['otro_negocio']!=null)
            {
                $tipo_negocio = $_POST['otro_negocio'];
            }
        }
        

        $date_hash =  hash('sha512',$date);
        $query_user = "INSERT INTO users (tipo,date_create,active,usrname,pass,email,hash_email,code,phone,tipo_negocio,company,admi,RFC,documento,documentoN,date_token,token) 
                            VALUES('$tipo','$date','0','$name','$pass_u','$email','$hash_email','$code','$phone','$tipo_negocio','$company','$admi','$RFC','$image','$file_name','$date','$date_hash')";//agregar tipodeuser              
        $verificar = mysqli_query($conexion,$query_user);
        $idusr = mysqli_insert_id ($conexion);
        $query_dir = "INSERT INTO address_t (id_user,country,full_name,company,street_address1,street_address2,city,zip_code,statedir,default_address) 
                                    VALUES('$idusr','$country','$name','$company','$address1','$address2','$locality','$zipcode','$state','1')";//agregar tipodeuser
        $verificar_2 = mysqli_query($conexion,$query_dir);
        if($verificar)
        {
            $form_data['error'] = "0";
            $from = "notificaciones@ografix.com";
            $to = $email;
            $linkverifica = "https://www.ografix.com/activacion?email=".$hash_email."&token=".$date_hash;
            $subject = "Confirmación de registro";
            $subject = "=?UTF-8?B?".base64_encode($subject)."=?=";
            $message = "Hola ". $name ."<br>
                        <br>
                        Para poder completar tu registro da click en el siguiente link:<br>
                        <br>
                        <a href='". $linkverifica ."'>". $linkverifica ."</a><br>
                        <br>
                        <br>
                        Saludos,<br>
                        <br>
                        ografix";
            require('phpmailer/class.phpmailer.php');
            $mail = new PHPMailer();
            $mail->IsSMTP();
            $mail->SMTPDebug = 1;
            $mail->Debugoutput = 'html';
            $mail->SMTPAuth = TRUE;
            $mail->SMTPSecure = "ssl";
            $mail->Port     = 465;  
            $mail->Username = "notificaciones@ografix.com";
            $mail->Password = "tlk3QOsEuN2.";
            $mail->Host     = "mail.ografix.com";
            $mail->Mailer   = "smtp";
            $mail->SetFrom("notificaciones@ografix.com","ografix");
            $mail->AddAddress($to);	
            $mail->Subject = $subject;
            $mail->Body    = $message;
            $mail->WordWrap   = 80;
            $mail->CharSet = 'UTF-8';
            $mail->IsHTML(true);
            if(!$mail->Send())
            {
                //echo "Problem in Sending Mail";
            }
            else 
            {
              
                //echo "Mail Sent Successfully";
            }
            $form_data['error'] = "0";
            $from = "notificaciones@ografix.com";
            $to = "ografix.info@gmail.com";
            $subject = "Confirmación de registro";
            $message = "Hola 
                        Se ha registrado un nuevo cliente
                        <br>
                        ".$name."
                        <br>
                        ".$email." 
                        <br>
                        ".$company." 
                        <br>
                        <br>
                        ografix";
            
            $mail = new PHPMailer();
            $mail->IsSMTP();
            $mail->SMTPDebug = 1;
            $mail->Debugoutput = 'html';
            $mail->SMTPAuth = TRUE;
            $mail->SMTPSecure = "ssl";
            $mail->Port     = 465;  
            $mail->Username = "notificaciones@ografix.com";
            $mail->Password = "tlk3QOsEuN2.";
            $mail->Host     = "mail.ografix.com";
            $mail->Mailer   = "smtp";
            $mail->SetFrom("notificaciones@ografix.com","ografix");
            $mail->AddAddress($to);	
            $mail->Subject = $subject;
            $mail->Body    = $message;
            $mail->WordWrap   = 80;
            $mail->CharSet = 'UTF-8';
            $mail->IsHTML(true);
            if(!$mail->Send())
            {
            }
            else 
            {
            }
            mysqli_close($conexion);
            
        }
        else
        {
            $form_data['error'] = "2";
            mysqli_close($conexion);

        }
    } 
    echo json_encode($form_data);
  /*echo json_encode($form_data);
    mysqli_close($conexion);
    return;*/
    
?>