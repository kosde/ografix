<?php
$code    = $_POST["code"];
//$code    = $_GET["code"];
$id_user = $_POST["usr_id"];
include 'conexion.php';
$form_data = array();
$dateNow = date_create($date_Now);
$validar  = mysqli_query($conexion,"SELECT * FROM cupones WHERE nombre='$code'");
if(mysqli_num_rows($validar)>0)
{
    $extraido= mysqli_fetch_array($validar);
    $form_data["fecha_inicio"]  = $extraido["fecha_inicio"];
    $form_data["fecha_final"]   = $extraido['fecha_final'];
    $form_data["cantidad"]      = $extraido['cantidad'];
    $form_data["aplicado"]      = $extraido['aplicado'];
    /*$interval                   = date_diff($dateNow,date_create($extraido["fecha_inicio"]));
    $interval2                  = date_diff($dateNow, date_create($extraido["fecha_final"]));
    $form_data["y"]             = $interval2["y"];
    $form_data["m"]             = $interval2["m"];
    $form_data["d"]             = $interval2["d"];
    $form_data["h"]             = $interval2["h"];
    
    if($interval['y'] == 0 && $interval['m'] == 0 && $interval['d'] == 0 && $interval['h'] <= 8)
    {
    }*/
}
mysqli_close($conexion);
echo json_encode($form_data);
?>