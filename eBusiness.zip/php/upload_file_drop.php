<?php
    session_start();
    $datezone=date_default_timezone_get();
    include 'conexion.php';
    require_once "../vendor/autoload.php";
    require_once "../config_cloud.php";
    //$nombre = $_POST['file-name'];
    $nombre = $_FILES['file']['name'];
    $file = $_FILES['file']['tmp_name'];
    $image = addslashes(file_get_contents($_FILES['file']['tmp_name'])); 
    $image_text = $_POST['image_text'];
    $query = "INSERT INTO images (nombre ,images) VALUES ('$nombre','$image')";
    $validar  = mysqli_query($conexion,$query);
    $id_uplad_image = mysqli_insert_id ($conexion);

    if(isset($_FILES['file2']['name']))
    {
        echo " /si hay 2do archivo/ ";
        $nombre2 = $_FILES['file2']['name'];
        $file2 = $_FILES['file2']['tmp_name'];
        $image2 = addslashes(file_get_contents($_FILES['file2']['tmp_name'])); 
        $query2 = "INSERT INTO images (nombre ,images) VALUES ('$nombre2','$image2')";
        $validar2  = mysqli_query($conexion,$query2);
        $id_uplad_image2 = mysqli_insert_id ($conexion);
    }
    if(!isset($_SESSION['id']))
    {
        $date = date('Y-m-d H:i');
        $query = "INSERT INTO users (temporal,date_create)VALUES('1','$date')";            
        $ejecutar = mysqli_query($conexion,$query);
        $_SESSION['id'] = mysqli_insert_id ($conexion);
    }
    if ($validar)
    {
        $tipo = $_SESSION['tipo'];
        $medida = explode('x',$_SESSION['medida']);// $_SESSION['medida'];
        $quantity = $_SESSION['quantity'];
        $vista = $_SESSION['vista'];
        $acabado = $_SESSION['acabado'];
        $redond = $_SESSION['redond'];
        $filename = $_SESSION['filename'];
        $producto = $_SESSION['producto'];
        $precioproducto = $_SESSION['precioproducto'];
        $preciofinal = $_SESSION['preciofinal'];
        $precioesquinas = $_SESSION['precioesquinas'];
        $corte = $_SESSION['corte'];
        $width = $medida[0];
        $height = $medida[1];
        $id =  $_SESSION['id'];
        $date = date('Y-m-d H:i');
        if($_SESSION['producto'] == "Tarjetas")
        {
            $lados = $_SESSION['lado1'].$_SESSION['lado2'].$_SESSION['lado3'].$_SESSION['lado4'];
            $ponchado =  $_SESSION['perfo1'].$_SESSION['perfo2'].$_SESSION['perfo3'].$_SESSION['perfo4'].$_SESSION['perfo5'].$_SESSION['perfo6'].$_SESSION['perfo7'].$_SESSION['perfo8'];
            if(isset($_FILES['file2']['name']))
            {
                $query_cart = "INSERT INTO cart (id_user,width_inches,height_inches,price,tipe,quantity,id_images,id_images_vuelta,txt_details,dates,vista,acabado,esquinas,ponchado,corte) 
                                VALUES('$id','$width','$height','$preciofinal','$producto','$quantity','$id_uplad_image2','$id_uplad_image','$image_text','$date','$vista','$acabado','$lados','$ponchado','$corte')";
            }
            else
            {
                $query_cart = "INSERT INTO cart (id_user,width_inches,height_inches,price,tipe,quantity,id_images,txt_details,dates,vista,acabado,esquinas,ponchado,corte) 
                                VALUES('$id','$width','$height','$preciofinal','$producto','$quantity','$id_uplad_image','$image_text','$date','$vista','$acabado','$lados','$ponchado','$corte')";
            }   
        }
        if($producto == "Diseño de tarjetas")
        {
            if($_SESSION['tipo'] == 0)
                $preciofinal = 99;
            else
                $preciofinal = 69;
            $lados = $_SESSION['lados'];
            $ponchado = $_SESSION['ponchado'];
            $query_cart = "INSERT INTO cart (id_user,width_inches,height_inches,price,tipe,quantity,id_images,id_images_vuelta,txt_details,dates,vista,acabado,esquinas,ponchado,corte,statusp) 
                            VALUES('$id','$width','$height','$preciofinal','$producto','1','$id_uplad_image2','$id_uplad_image','$image_text','$date','$vista','$acabado','$lados','$ponchado','$corte',10)";
        }
        
        
        $cart= mysqli_query($conexion,$query_cart);
        //mysqli_close($conexion);     
    }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Ografix</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <!-- 5-=DXbZ]Ggah -->
    <link href="img/ICONO.png" rel="icon">
    <link href="img/ICONO.png" rel="apple-touch-icon">
    <?php
    include "css.php";
    ?>
</head>
<body>
    <main>
    <?php
        echo "imagen1";
        $images = mysqli_query($conexion,"SELECT * FROM images WHERE id ='$id_uplad_image'");
        $folder = 'usr_'.$id;
        if(mysqli_num_rows($images)>0)
        {
            echo " /si existe imagen1/ ";
            while ($extraido2= mysqli_fetch_array($images))
            {
                echo " /se encontro imagen1/ ";
                $id_i = $extraido2['id'];
                $name_image = $extraido2['nombre'];
                ?>
                <div  id="mycontent">
                    <img style="width:60px;" src="data:image/png;base64,<?php echo base64_encode($extraido2['images']); ?> ">
                </div>
               <?php
               echo " /procesando imagen1/ ";
               $extension = pathinfo($nombre , PATHINFO_EXTENSION);
               $nombre_base = basename($nombre , '.'.$extension);  
               \Cloudinary\Uploader::upload($file, ["folder" => strval($folder),"public_id" => $nombre_base]);
               echo " /se proceso imagen1/ ";
            }
        }
        echo "imagen2";
        if(isset($id_uplad_image2))
        {
            echo " /si existe imagen2/ ";
            $images = mysqli_query($conexion,"SELECT * FROM images WHERE id ='$id_uplad_image2'");
            $folder = 'usr_'.$id;
            if(mysqli_num_rows($images)>0)
            {
                echo " /se encontro imagen2/ ";
                while ($extraido2= mysqli_fetch_array($images))
                {
                    echo " /se encontro imagen2/ ";
                    $id_i = $extraido2['id'];
                    $name_image = $extraido2['nombre'];
                    ?>
                    <div  id="mycontent">
                        <img style="width:60px;" src="data:image/png;base64,<?php echo base64_encode($extraido2['images']); ?> ">
                    </div>
                <?php
                echo " /procesando imagen2/ ";
                $extension = pathinfo($nombre2 , PATHINFO_EXTENSION);
                echo " /extencion...".$extension."...extencion/ ";
                $nombre_base = basename($nombre2 , '.'.$extension);  
                \Cloudinary\Uploader::upload($file2, ["folder" => strval($folder),"public_id" => $nombre_base]);
                echo $folder;
                echo $nombre_base;
                echo " /se proceso imagen2/ ";
                }
            }
        }
        mysqli_close($conexion);
        echo'
            <script>
                window.location = "../cart.php";
            </script>
            ';
    ?>
    </main>

<a href="#" class="back-to-top"><i class="fa fa-c hevron-up"></i></a>

<!-- JavaScript Libraries 
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>-->


</body>

</html>
