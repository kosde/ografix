<?php
\Cloudinary::config(array( 
    "cloud_name" => 'ografix', 
    "api_key" => '782562937425634', 
    "api_secret" => '8lV6whAUCa3xyWQUlaG6Q1SfX4s'
));
?>